Pages

Home
Product detail
Cart
Login / Register
Address
payment
order success

User panel
profile CRUD
Adreess CRUD
order view

Admin panel
Product CRUD
User CRUD
Order History
Stats
CMS
